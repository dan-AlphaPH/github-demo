const colors = ['#2196f3', '#e91e63', '#ff3b3b', '#74ff1d'];
const btn__circle = document.querySelector('.btn__circle');
const btn__square = document.querySelector('.btn__square');
const btn__triangle = document.querySelector('.btn__triangle');
const btn__add = document.querySelector('.btn__add');
let bool__square = true;
let bool__circle = false;
let bool__triangle = false;
let bool__add = false;

function color255() {
  const colr = Math.trunc(Math.random() * 255) + 1;
  const colg = Math.trunc(Math.random() * 255) + 1;
  const colb = Math.trunc(Math.random() * 255) + 1;
  const cola = Math.trunc(Math.random() * 255) + 1;
  return `rgba(${colr}, ${colg}, ${colb}, ${cola})`;
}
//
function createSquare() {
  const section = document.querySelector('section');
  const square = document.createElement('span');
  const shp__icon = document.createElement('ion-icon');

  var size = Math.random() * 75;

  square.style.width = 20 + size + 'px';
  square.style.height = 20 + size + 'px';
  shp__icon.style.fontSize = square.style.top =
    Math.random() * innerHeight + 'px';
  square.style.left = Math.random() * innerWidth + 'px';
  shp__icon.style.fontSize = 20 + size + 'px';

  //Choose colors from array
  //const bg = colors[Math.floor(Math.random() * colors.length)];

  //Randomize colors
  const bg = color255();

  square.style.background = 'none';

  if (bool__square) {
    shp__icon.name = 'square';
  } else if (bool__circle) {
    shp__icon.name = 'ellipse';
  } else if (bool__triangle) {
    shp__icon.name = 'triangle';
  } else if (bool__add) {
    shp__icon.name = 'add-outline';
  }

  square.style.color = bg;
  square.appendChild(shp__icon);
  section.appendChild(square);

  setTimeout(() => {
    square.remove();
  }, 2050);
}
///Main

btn__circle.addEventListener('click', function () {
  //btn__circle.textContent = 'Working';
  bool__square = false;
  bool__circle = true;
  bool__add = false;
  bool__triangle = false;
});

btn__square.addEventListener('click', function () {
  bool__square = true;
  bool__circle = false;
  bool__add = false;
  bool__triangle = false;
});

btn__triangle.addEventListener('click', function () {
  bool__square = false;
  bool__add = false;
  bool__circle = false;
  bool__triangle = true;
});
btn__add.addEventListener('click', function () {
  bool__square = false;
  bool__add = true;
  bool__circle = false;
  bool__triangle = false;
});
setInterval(createSquare, 100);
